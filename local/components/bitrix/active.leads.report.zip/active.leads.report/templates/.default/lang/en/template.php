<?
$MESS["CRM_EVENT_TABLE_EMPTY"] = "- No data -";
$MESS["CRM_EVENT_TABLE_FILES"] = "Files";
$MESS["CRM_EVENT_DELETE"] = "Delete";
$MESS["CRM_EVENT_DELETE_TITLE"] = "Delete Event";
$MESS["CRM_EVENT_DELETE_CONFIRM"] = "Are you sure you want to delete it?";
$MESS["CRM_ALL"] = "Total";
$MESS["CRM_IMPORT_EVENT"] = "If the contact's email is specified in the CRM record you can automatically save all related email correspondence as an Event record. You need to forward received message to the system's email address <b>%EMAIL%</b> and all text and attached files will be added as Events for this Contact.";
$MESS["CRM_EVENT_VIEW_ADD_SHORT"] = "Event";
$MESS["CRM_EVENT_VIEW_ADD"] = "Add event";
$MESS["CRM_EVENT_VIEW_SHOW_FILTER_SHORT"] = "Filter";
$MESS["CRM_EVENT_VIEW_SHOW_FILTER"] = "Show/hide filter";
$MESS["CRM_SHOW_ROW_COUNT"] = "Show quantity";
?>