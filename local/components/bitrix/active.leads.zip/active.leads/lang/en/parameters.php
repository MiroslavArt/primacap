<?
$MESS["CRM_ENTITY_TYPE"] = "Entity Type";
$MESS["CRM_ENTITY_ID"] = "Entity ID";
$MESS["CRM_EVENT_COUNT"] = "Events Per Page";
$MESS["CRM_EVENT_ENTITY_LINK"] = "Show Entity Title";
$MESS["CRM_ENTITY_TYPE_LEAD"] = "Lead";
$MESS["CRM_ENTITY_TYPE_CONTACT"] = "Contact";
$MESS["CRM_ENTITY_TYPE_COMPANY"] = "Company";
$MESS["CRM_ENTITY_TYPE_DEAL"] = "Deal";
$MESS["CRM_NAME_TEMPLATE"] = "Name format";
$MESS["CRM_ENTITY_TYPE_QUOTE"] = "Quote";
?>