<?php
include($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
   \Bitrix\Main\UI\Extension::load("ui.tooltip");
global $DB,$USER;

$current_user=getBitrixUserSubEmployees($USER->GetID());

if(!$USER->IsAdmin() && empty($current_user)) {echo "Access Denied"; die();}

if(!empty($current_user)) {
 $sub = implode(', ', $current_user);
}

$currentdate=date('d-m-Y');
if($_REQUEST['fromdate']!='')
{
$fromdate=$_REQUEST['fromdate']." 00:00:00";
$todate=$_REQUEST['todate']." 23:59:59";
}





$strSql = "Select ID,NAME,SECOND_NAME,LAST_NAME,EMAIL,c.UF_DEPARTMENT AS DEP,c.UF_OFFICE_ATTN from b_user a,b_user_group b,b_uts_user c where a.active ='Y' and a.LID ='s1' and a.ID = b.USER_ID and b.GROUP_ID='11' and c.VALUE_ID=a.ID and a.ID NOT IN (1,27,1709,1013,4817,4818)  ORDER BY a.ID ASC";

$dbRes = $DB->Query($strSql);



 global $APPLICATION;

	$GLOBALS['APPLICATION']->SetAdditionalCSS('/local/components/bitrix/agent.score/templates/.default/datatables.min.css');

	$GLOBALS['APPLICATION']->AddHeadScript('/local/components/bitrix/agent.score/templates/.default/datatables.min.js');
?>

<h2>Boost Score</h2>
<style>
table#score tr:hover {background-color: #dadcda;cursor: pointer;}
table#score > tbody > tr.view:nth-child(even) {
  background: #eee;
}
input[type=date] {
  padding: 10px 8px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 11px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
input[type=reset] {
  background-color: #ff4444;
  color: white;
  padding: 11px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=reset]:hover {
  background-color: #ff4e4e;
}
 </style>

<table id="score" border='0'  cellpadding='8' cellspacing='0' width='100%'>
<thead>
<tr bgcolor='#8d9089'>
<th align='center' style='border:1px #f5f9f9 solid; color:#fff;'>Employee</th>
<th align='center' style='border:1px #f5f9f9 solid; color:#fff;'>Score (%)</th>
</tr>
</thead>
<?
while($arRes = $dbRes->Fetch())
{
    $agentId = $arRes['ID'];


$leadconvSql = $DB->query("SELECT COUNT(*) as lead_convertion_count FROM b_crm_lead WHERE ASSIGNED_BY_ID = '$agentId' AND STATUS_ID = 'CONVERTED'");
$leadconvRes = $leadconvSql->fetch();

$leadconvSqltot = $DB->query("SELECT COUNT(*) as lead_convertion_count FROM b_user a, b_user_group b, b_uts_user c, b_crm_lead d WHERE a.active ='Y' AND a.LID ='s1' AND a.ID = b.USER_ID AND b.GROUP_ID='11' AND c.VALUE_ID=a.ID AND a.ID NOT IN (1,27,1709,1013,4817,4818) AND a.ID=d.ASSIGNED_BY_ID AND d.STATUS_ID = 'CONVERTED'");
$leadconvRestot = $leadconvSqltot->fetch();


    $leadconv = ($leadconvRes['lead_convertion_count'] > 0) ? round($leadconvRes['lead_convertion_count'] / $leadconvRestot['lead_convertion_count'] * 600, 2) : 0;

    // Attendance
    $strtimeSql = $DB->query("SELECT SUM(TIMESTAMPDIFF(SECOND, DATE_START, DATE_FINISH)) AS score_time FROM b_timeman_entries WHERE USER_ID = '$agentId'");
    $timeRes = $strtimeSql->fetch();

    $strtimeSqltot = $DB->query("SELECT SUM(TIMESTAMPDIFF(SECOND, DATE_START, DATE_FINISH)) AS score_time FROM b_user a, b_user_group b, b_uts_user c, b_timeman_entries d WHERE a.active ='Y' AND a.LID ='s1' AND a.ID = b.USER_ID AND b.GROUP_ID='11' AND c.VALUE_ID=a.ID AND a.ID NOT IN (1,27,1709,1013,4817,4818) AND a.ID=d.USER_ID");
    $timeRestot = $strtimeSqltot->fetch();

    $timeSumper = ($timeRes['score_time'] > 0) ? round($timeRes['score_time'] / $timeRestot['score_time'] * 100, 2) : 0;

    // Office Attendance
    $stroftimeSql = $DB->query("SELECT TIMEDIFF(MAX(CASE WHEN PUNCH_DIRECTION = 'out' THEN LOG_DATE END), MIN(CASE WHEN PUNCH_DIRECTION = 'in' THEN LOG_DATE END)) AS WorkingHours FROM c_office_attandance WHERE USER_ID = '".$arRes['UF_OFFICE_ATTN']."'");
    $oftimeRes = $stroftimeSql->fetch();


    // Activities
    $stractSql = $DB->query("SELECT COUNT(*) as activities_count FROM b_crm_act WHERE RESPONSIBLE_ID = '$agentId' AND OWNER_TYPE_ID ='1'");
    $actRes = $stractSql->fetch();

    $stractSqltot = $DB->query("SELECT COUNT(*) as activities_count FROM b_user a, b_user_group b, b_uts_user c, b_crm_act d WHERE a.active ='Y' AND a.LID ='s1' AND a.ID = b.USER_ID AND b.GROUP_ID='11' AND c.VALUE_ID=a.ID AND a.ID NOT IN (1,27,1709,1013,4817,4818) AND a.ID=d.RESPONSIBLE_ID AND d.OWNER_TYPE_ID ='1'");
    $actRestot = $stractSqltot->fetch();

    $stractper = ($actRes['activities_count'] > 0) ? round($actRes['activities_count'] / $actRestot['activities_count'] * 150, 2) : 0;

    // Reactiveness
    $strproactSql = $DB->query("SELECT COUNT(*) as proactivities_count FROM c_distribution_lead_missing WHERE USER_ID = '$agentId'");
    $proactRes = $strproactSql->fetch();

    $strproactSqltot = $DB->query("SELECT COUNT(*) as proactivities_count FROM b_user a, b_user_group b, b_uts_user c, c_distribution_lead_missing d WHERE a.active ='Y' AND a.LID ='s1' AND a.ID = b.USER_ID AND b.GROUP_ID='11' AND c.VALUE_ID=a.ID AND a.ID NOT IN (1,27,1709,1013,4817,4818) AND a.ID=d.USER_ID");
    $proactRestot = $strproactSqltot->fetch();

    $proactper = ($proactRes['proactivities_count'] > 0) ? round($proactRes['proactivities_count'] / $proactRestot['proactivities_count'] * 150, 2) : 0;

    // Total Score
     $totalscore = ($leadconv) + ($timeSumper) + ($stractper) - ($proactper);
?>

<tr class="view">
<td align='left' style='border:1px #f5f9f9 solid;width:15%;'><a href="/company/personal/user/<?=$arRes['ID'];?>/" bx-tooltip-user-id="<?=$arRes['ID'];?>"><?=$arRes['NAME']." ".$arRes['LAST_NAME']; ?></a></td>
<td align='center' style='border:1px #f5f9f9 solid;width:5%;<? if($totalscore<0){ ?> color:red;<?}?>'><?=$totalscore;?>%</td>
</tr>
<?
} 
?>

</table>
<script>
	new DataTable('#score', {
    lengthMenu: [
        [20, 40, 60, -1],
        [20, 40, 60, 'All']
    ]
});
	</script>


<p style="color:red;">
	<span style="color:red;"><b>Notes:</b></span><br/>
    1. Each Employee Individual Percentage (100%) =  Lead Conversion (60%) + Attendance (10%) + Activities (15%) - Reactiveness (15%)<br/>
	2. Reactivness lead ID data is showing from <b>9th April 2024</b> <br/>
	3. Attandance data is showing from <b>15th April 2024</b><br/>
</p>