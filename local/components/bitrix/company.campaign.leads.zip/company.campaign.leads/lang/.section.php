<?
$sSectionName="lang";
?>