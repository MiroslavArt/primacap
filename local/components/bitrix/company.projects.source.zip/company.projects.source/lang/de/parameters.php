<?
$MESS["CRM_ENTITY_TYPE"] = "Einheitstyp";
$MESS["CRM_ENTITY_ID"] = "Einheit-ID";
$MESS["CRM_EVENT_COUNT"] = "Aktivitäten pro Seite";
$MESS["CRM_EVENT_ENTITY_LINK"] = "Einheitsüberschrift anzeigen";
$MESS["CRM_ENTITY_TYPE_LEAD"] = "Lead";
$MESS["CRM_ENTITY_TYPE_CONTACT"] = "Kontakt";
$MESS["CRM_ENTITY_TYPE_COMPANY"] = "Unternehmen";
$MESS["CRM_ENTITY_TYPE_DEAL"] = "Auftrag";
$MESS["CRM_NAME_TEMPLATE"] = "Namensformat";
$MESS["CRM_ENTITY_TYPE_QUOTE"] = "Angebot";
?>