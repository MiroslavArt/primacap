<?php

$arModuleVersion = array(
    'VERSION'      => '1.0.0',
    'VERSION_DATE' => '2022-10-30 10:00:00'
);