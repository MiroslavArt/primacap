<?php

$MESS['BIT_NOTE_ACT_MODULE_NAME'] = 'Bit. Notification activity';
$MESS['BIT_NOTE_ACT_MODULE_DESC'] = 'Send whatsapp message for crm-activity';
$MESS['BIT_NOTE_ACT_PARTNER_NAME'] = 'FirstBIT';
$MESS['BIT_NOTE_ACT_PARTNER_URI'] = 'https://1cbit.ru/';
