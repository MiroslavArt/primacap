<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Mais";
$MESS["WIDGET_CALENDAR_TITLE"] = "Proximos eventos";
?>