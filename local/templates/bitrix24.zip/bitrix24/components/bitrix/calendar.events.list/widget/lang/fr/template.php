<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "En savoir plus";
$MESS["WIDGET_CALENDAR_TITLE"] = "Evénements à venir";
?>