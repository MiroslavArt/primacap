<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "अधिक";
$MESS["WIDGET_CALENDAR_TITLE"] = "आने वाले इवेंट";
?>