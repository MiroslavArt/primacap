<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Selengkapnya";
$MESS["WIDGET_CALENDAR_TITLE"] = "Event Mendatang";
?>