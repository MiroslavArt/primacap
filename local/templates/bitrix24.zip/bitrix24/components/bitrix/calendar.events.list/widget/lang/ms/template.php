<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Lebih lagi";
$MESS["WIDGET_CALENDAR_TITLE"] = "Acara Yang Akan Datang";
?>