<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Więcej";
$MESS["WIDGET_CALENDAR_TITLE"] = "Nadchodzące wydarzenia";
?>