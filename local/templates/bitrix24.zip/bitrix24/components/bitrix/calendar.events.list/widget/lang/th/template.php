<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "เพิ่มเติม";
$MESS["WIDGET_CALENDAR_TITLE"] = "เหตุการณ์ที่จะมาถึง";
?>