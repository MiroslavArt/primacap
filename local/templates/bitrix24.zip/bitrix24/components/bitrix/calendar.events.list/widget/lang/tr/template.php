<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Daha fazla";
$MESS["WIDGET_CALENDAR_TITLE"] = "Yaklaşan Etkinlikler";
?>