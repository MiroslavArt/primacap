<?
$MESS["WIDGET_CALENDAR_DETAILS"] = "Thêm";
$MESS["WIDGET_CALENDAR_TITLE"] = "Các sự kiện sắp tới";
?>