<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arTemplateParameters = array(
	"SHOW_FILTER" => array(
		"NAME" => GetMessage('INTR_ISBN_TPL_PARAM_SHOW_FILTER'),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'Y',
	),
); 
?>