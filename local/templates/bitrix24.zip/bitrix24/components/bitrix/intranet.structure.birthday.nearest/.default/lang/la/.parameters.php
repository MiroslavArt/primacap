<?
$MESS["INTR_ISBN_TPL_PARAM_SHOW_FILTER"] = "Mostrar filtros";
?>