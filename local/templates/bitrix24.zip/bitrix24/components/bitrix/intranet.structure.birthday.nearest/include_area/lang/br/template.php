<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Para a empresa inteira";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Para o meu office";
?>