<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Afficher pour toute l'entreprise";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Montrer pour mon bureau";
?>