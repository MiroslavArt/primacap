<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "पूरी कंपनी के लिए";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "मेरे ऑफिस के लिए";
?>