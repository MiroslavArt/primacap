<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Untuk seluruh perusahaan";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Untuk kantor saya";
?>