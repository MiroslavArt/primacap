<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Per l'intera azienda";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Per il mio ufficio";
?>