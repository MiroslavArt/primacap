<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Para toda la compañía";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Para mi oficina";
?>