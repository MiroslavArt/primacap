<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Untuk seluruh syarikat";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Untuk pejabat saya";
?>