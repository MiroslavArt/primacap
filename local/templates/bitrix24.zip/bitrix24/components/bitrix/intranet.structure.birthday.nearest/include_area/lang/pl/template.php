<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Dla całej firmy";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Dla mojego biura";
?>