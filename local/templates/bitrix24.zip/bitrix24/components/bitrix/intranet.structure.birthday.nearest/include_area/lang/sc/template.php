<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "对于整个公司";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "对于我的办公室";
?>