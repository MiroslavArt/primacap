<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "針對全公司";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "針對我的辦公室";
?>