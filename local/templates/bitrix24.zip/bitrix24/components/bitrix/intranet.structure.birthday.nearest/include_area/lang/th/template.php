<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "สำหรับทั้งบริษัท";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "สำหรับที่ทำงานของฉัน";
?>