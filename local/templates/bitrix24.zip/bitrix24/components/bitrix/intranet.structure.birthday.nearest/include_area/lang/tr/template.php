<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Tüm şirket için";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Ofisim için";
?>