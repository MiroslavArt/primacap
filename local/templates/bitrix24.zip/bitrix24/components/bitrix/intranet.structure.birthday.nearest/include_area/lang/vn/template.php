<?
$MESS["INTR_ISBN_TPL_FILTER_ALL"] = "Đối với toàn bộ công ty";
$MESS["INTR_ISBN_TPL_FILTER_MINE"] = "Đối với văn phòng của tôi";
?>