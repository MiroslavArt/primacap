<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "Aniversários";
?>