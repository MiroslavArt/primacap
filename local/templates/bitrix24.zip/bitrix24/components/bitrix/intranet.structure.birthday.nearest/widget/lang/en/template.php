<?
$MESS['WIDGET_BIRTHDAY_TITLE'] = 'Birthdays';
?>