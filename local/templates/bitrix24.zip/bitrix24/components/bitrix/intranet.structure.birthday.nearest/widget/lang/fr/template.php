<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "Anniversaires";
?>