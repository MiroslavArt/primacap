<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "जन्मदिन";
?>