<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "Ulang Tahun";
?>