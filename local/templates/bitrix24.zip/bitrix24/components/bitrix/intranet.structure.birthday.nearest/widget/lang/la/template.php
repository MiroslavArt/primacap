<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "Cumpleaños";
?>