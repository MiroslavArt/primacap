<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "Hari Lahir";
?>