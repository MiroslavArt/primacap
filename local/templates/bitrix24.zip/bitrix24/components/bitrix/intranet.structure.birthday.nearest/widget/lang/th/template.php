<?
$MESS["WIDGET_BIRTHDAY_TITLE"] = "วันเกิด";
?>