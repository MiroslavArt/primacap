<?
$MESS["ISL_ID"] = "आईडी";
?>