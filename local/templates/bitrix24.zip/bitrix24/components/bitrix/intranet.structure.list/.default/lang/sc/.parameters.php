<?
$MESS["ISL_ID"] = "ID";
$MESS["ISL_PERSONAL_ICQ"] = "ICQ";
?>