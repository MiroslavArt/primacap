<?
$MESS["ISL_ID"] = "ไอดี";
$MESS["ISL_PERSONAL_ICQ"] = "ICQ";
?>