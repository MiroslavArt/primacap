<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Adicionar empregado";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Gerenciar Funcionários";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Importar funcionários";
?>