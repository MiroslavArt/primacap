<?
$MESS ['INTR_ABSC_TPL_ADD_ENTRY'] = "Add employee";
$MESS ['INTR_ABSC_TPL_EDIT_ENTRIES'] = "Manage Employees";
$MESS ['INTR_ABSC_TPL_IMPORT'] = "Import Employees";
?>