<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Ajouter un employé (utilisateur)";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Gestion du personnel";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Importer des employés";
?>