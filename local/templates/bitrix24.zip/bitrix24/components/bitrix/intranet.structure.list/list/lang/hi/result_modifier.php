<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "कर्मचारी जोड़ें";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "कर्मचारी प्रबंधित करें";
$MESS["INTR_ABSC_TPL_IMPORT"] = "कर्मचारी इंपोर्ट करें";
?>