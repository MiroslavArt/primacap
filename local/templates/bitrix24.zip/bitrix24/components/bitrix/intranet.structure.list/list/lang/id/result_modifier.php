<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Tambahkan karyawan";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Kelola Karyawan";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Impor Karyawan";
?>