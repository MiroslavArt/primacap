<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Aggiungi dipendente";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Gestisci dipendenti";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Importa dipendenti";
?>