<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "エントリを追加";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "従業員管理";
$MESS["INTR_ABSC_TPL_IMPORT"] = "従業員のインポート";
?>