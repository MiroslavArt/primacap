<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Agregar empleado";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Gestión de empleados";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Importar empleados";
?>