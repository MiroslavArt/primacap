<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Pridėti darbuotoją";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Valdyti darbuotojus";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Importuoti darbuotojus";
?>