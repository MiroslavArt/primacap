<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Tambah pekerja";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Urus Pekerja";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Import Pekerja";
?>