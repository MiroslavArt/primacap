<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "เพิ่มพนักงาน";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "จัดการพนักงาน";
$MESS["INTR_ABSC_TPL_IMPORT"] = "นำเข้าพนักงาน";
?>