<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Додати співробітника";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Управління співробітниками";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Імпорт співробітників";
?>