<?
$MESS["INTR_ABSC_TPL_ADD_ENTRY"] = "Thêm nhân viên";
$MESS["INTR_ABSC_TPL_EDIT_ENTRIES"] = "Quản lý nhân viên";
$MESS["INTR_ABSC_TPL_IMPORT"] = "Nhân viên nhập khẩu";
?>