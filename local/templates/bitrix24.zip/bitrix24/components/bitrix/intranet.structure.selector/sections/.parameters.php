<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTemplateParameters = array(
	"SHOW_SECTION_INFO"=>array(
		"NAME" => GetMessage('INTR_ISS_TPL_PARAM_SHOW_SECTION_INFO'),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'N',
	),
); 
?>