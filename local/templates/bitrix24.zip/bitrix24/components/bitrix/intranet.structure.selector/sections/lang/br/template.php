<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Sobre o departamento";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Departamento dos pais";
?>