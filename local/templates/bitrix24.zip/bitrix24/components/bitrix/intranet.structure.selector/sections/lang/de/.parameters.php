<?
$MESS["INTR_ISS_TPL_PARAM_SHOW_SECTION_INFO"] = "Angaben über die Abteilung anzeigen";
?>