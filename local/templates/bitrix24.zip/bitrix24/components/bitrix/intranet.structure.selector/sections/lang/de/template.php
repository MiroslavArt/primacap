<?
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Übergeordnete Abteilung";
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Über die Abteilung";
?>