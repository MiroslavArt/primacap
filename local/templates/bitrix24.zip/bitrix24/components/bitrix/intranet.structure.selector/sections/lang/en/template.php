<?
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Parent department";
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "About department";
?>