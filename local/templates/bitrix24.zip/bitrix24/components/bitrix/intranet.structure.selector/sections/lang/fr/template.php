<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Sur du service";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Subdivision supérieure";
?>