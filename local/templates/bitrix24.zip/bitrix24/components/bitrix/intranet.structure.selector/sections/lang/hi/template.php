<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "विभाग के बारे में";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "पेरेंट डिपार्टमेंट";
?>