<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Tentang departemen";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Departemen induk";
?>