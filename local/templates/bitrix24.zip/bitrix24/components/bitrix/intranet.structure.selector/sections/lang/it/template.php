<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Info sul reparto";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Reparto principale";
?>