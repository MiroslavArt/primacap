<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Acerca del departamento";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Departamento principal ";
?>