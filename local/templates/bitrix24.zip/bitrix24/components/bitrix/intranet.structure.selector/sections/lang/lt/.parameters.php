<?
$MESS["INTR_ISS_TPL_PARAM_SHOW_SECTION_INFO"] = "Rodyti skyriaus informaciją";
?>