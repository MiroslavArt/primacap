<?
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Pagrindinis skyrius";
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Apie skyrių";
?>