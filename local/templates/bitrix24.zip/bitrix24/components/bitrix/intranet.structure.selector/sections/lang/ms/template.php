<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Mengenai jabatan";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Jabatan induk";
?>