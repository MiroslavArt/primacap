<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "O dziale";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Dział nadrzędny";
?>