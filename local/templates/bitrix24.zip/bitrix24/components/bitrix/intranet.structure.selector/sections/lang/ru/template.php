<?
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Вышестоящее подразделение";
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Об отделе";
?>