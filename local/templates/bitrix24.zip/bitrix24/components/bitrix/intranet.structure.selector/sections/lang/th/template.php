<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "เกี่ยวกับแผนก";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "แผนกแม่";
?>