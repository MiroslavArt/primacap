<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Departman hakkında";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Üst departman";
?>