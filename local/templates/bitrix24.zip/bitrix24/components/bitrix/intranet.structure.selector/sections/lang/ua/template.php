<?
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Вищестоящий підрозділ";
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Про відділ";
?>