<?
$MESS["INTR_STR_ABOUT_DEPARTMENT"] = "Giới thiệu về phòng ban";
$MESS["INTR_STR_HEAD_DEPARTMENT"] = "Phòng ban cha ";
?>