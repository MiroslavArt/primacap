<?
$MESS ['SONET_C10_DO_SAVE'] = "Pašalinti iš moderatorių";
$MESS ['SONET_C10_SUBTITLE'] = "Grupės moderatoriai";
$MESS ['SONET_C10_ONLINE'] = "Šiuo metu tinklapyje";
$MESS ['SONET_C10_NO_MODS'] = "Nėra moderatorių.";
$MESS ['SONET_C10_NO_MODS_DESCR'] = "Čia rodomi grupės moderatoriai.";
$MESS ['SONET_C10_DO_SET'] = "Paskirti moderatorių";
$MESS ['SONET_C10_OWNER'] = "Savininkas";
$MESS ['SONET_C10_T_OWNER'] = "Pakeisti savininką";
?>