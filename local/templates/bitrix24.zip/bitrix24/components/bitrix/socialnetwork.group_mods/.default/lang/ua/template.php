<?
$MESS["SONET_C10_DO_SAVE"] = "Виключити з модераторів";
$MESS["SONET_C10_SUBTITLE"] = "Модератори групи";
$MESS["SONET_C10_ONLINE"] = "Зараз на сайті";
$MESS["SONET_C10_NO_MODS"] = "Немає модераторів";
$MESS["SONET_C10_NO_MODS_DESCR"] = "Тут показуються модератори групи.";
$MESS["SONET_C10_DO_SET"] = "Призначити модераторів";
$MESS["SONET_C10_OWNER"] = "Власник";
$MESS["SONET_C10_T_OWNER"] = "Змінити власника";
?>