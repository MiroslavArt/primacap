<?
$MESS["WIDGET_RATING_TITLE"] = "Classificação";
?>