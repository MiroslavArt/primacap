<?
$MESS["WIDGET_RATING_TITLE"] = "Rating";
?>