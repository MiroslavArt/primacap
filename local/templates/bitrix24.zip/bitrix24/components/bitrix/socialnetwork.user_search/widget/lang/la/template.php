<?
$MESS["WIDGET_RATING_TITLE"] = "Clasificación";
?>