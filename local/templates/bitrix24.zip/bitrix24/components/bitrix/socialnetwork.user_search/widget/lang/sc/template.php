<?
$MESS["WIDGET_RATING_TITLE"] = "评级";
?>