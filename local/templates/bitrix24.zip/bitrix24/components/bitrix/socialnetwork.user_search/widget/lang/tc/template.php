<?
$MESS["WIDGET_RATING_TITLE"] = "評等";
?>