<?
$MESS["WIDGET_RATING_TITLE"] = "Xếp hạng";
?>