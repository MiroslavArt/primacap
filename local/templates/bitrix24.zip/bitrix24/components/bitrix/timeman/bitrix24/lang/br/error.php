<?
$MESS["TM_ERROR_WRONG_DATE"] = "Erro com definições de data / horário local!";
?>