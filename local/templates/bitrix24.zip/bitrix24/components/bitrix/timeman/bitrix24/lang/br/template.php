<?php
$MESS["TM_STATUS_COMPLETED"] = "Dia finalizado";
$MESS["TM_STATUS_EXPIRED"] = "Você <strong>não fechou</strong><br/>o dia útil anterior.";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "Você <strong>não marcou a saída</strong><br/>no dia anterior.";
$MESS["TM_STATUS_PAUSED"] = "Em pausa";
$MESS["TM_STATUS_START"] = "Iniciar o dia";
$MESS["TM_STATUS_WORK"] = "Trabalhando";
