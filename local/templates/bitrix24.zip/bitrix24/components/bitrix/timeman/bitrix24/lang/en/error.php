<?
$MESS["TM_ERROR_WRONG_DATE"] = "Error with local date/time settings!";
?>