<?php
$MESS["TM_STATUS_COMPLETED"] = "Clocked out";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "You <strong>didn't clock out</strong><br/>the previous day.";
$MESS["TM_STATUS_PAUSED"] = "On break";
$MESS["TM_STATUS_START"] = "Clock in";
$MESS["TM_STATUS_WORK"] = "Working";
