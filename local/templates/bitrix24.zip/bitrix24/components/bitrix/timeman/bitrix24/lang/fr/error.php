<?
$MESS["TM_ERROR_WRONG_DATE"] = "Défaut de la date locale !";
?>