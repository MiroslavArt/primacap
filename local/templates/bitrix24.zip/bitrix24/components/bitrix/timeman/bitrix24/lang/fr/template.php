<?php
$MESS["TM_STATUS_COMPLETED"] = "N'est pas à son poste";
$MESS["TM_STATUS_EXPIRED"] = "Vous <strong>n'avez pas fermé</strong><br/>la journée de travail précédente.";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "Vous <strong>n'avez pas pointé votre sortie</strong><br/> la journée de travail précédente.";
$MESS["TM_STATUS_PAUSED"] = "Pause";
$MESS["TM_STATUS_START"] = "Commencer";
$MESS["TM_STATUS_WORK"] = "Je travaille";
