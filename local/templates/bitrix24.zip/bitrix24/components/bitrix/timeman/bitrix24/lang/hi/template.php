<?
$MESS["TM_STATUS_COMPLETED"] = "समापन समय";
$MESS["TM_STATUS_EXPIRED"] = "आपने पिछला कार्य दिवस <br/><strong>बंद नहीं किया है</strong>";
$MESS["TM_STATUS_PAUSED"] = "छुट्टी पर";
$MESS["TM_STATUS_START"] = "आरंभ समय";
$MESS["TM_STATUS_WORK"] = "कामकाजी";
?>