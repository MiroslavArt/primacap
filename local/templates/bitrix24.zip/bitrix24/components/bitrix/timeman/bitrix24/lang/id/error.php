<?
$MESS["TM_ERROR_WRONG_DATE"] = "Kesalahan pada pengaturan tanggal/waktu lokal!";
?>