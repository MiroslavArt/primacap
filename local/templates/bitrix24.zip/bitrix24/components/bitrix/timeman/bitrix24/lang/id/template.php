<?
$MESS["TM_STATUS_COMPLETED"] = "Waktu sudah habis";
$MESS["TM_STATUS_EXPIRED"] = "Anda <strong>belum menutup</strong><br/> hari kerja sebelumnya.";
$MESS["TM_STATUS_PAUSED"] = "Beristirahat";
$MESS["TM_STATUS_START"] = "Waktu mulai";
$MESS["TM_STATUS_WORK"] = "Bekerja";
?>