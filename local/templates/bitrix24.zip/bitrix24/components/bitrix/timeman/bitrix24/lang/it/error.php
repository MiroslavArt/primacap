<?
$MESS["TM_ERROR_WRONG_DATE"] = "Errore con le impostazioni locali di data/ora!";
?>