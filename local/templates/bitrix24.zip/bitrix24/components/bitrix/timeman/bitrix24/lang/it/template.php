<?php
$MESS["TM_STATUS_COMPLETED"] = "Ora di uscita registrata";
$MESS["TM_STATUS_EXPIRED"] = "<strong>Non hai chiuso</strong><br/>la giornata lavorativa precedente.";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "<strong>Non hai registrato l'uscita</strong><br/>nella giornata lavorativa precedente.";
$MESS["TM_STATUS_PAUSED"] = "In pausa";
$MESS["TM_STATUS_START"] = "Ora di entrata registrata";
$MESS["TM_STATUS_WORK"] = "Lavoro";
