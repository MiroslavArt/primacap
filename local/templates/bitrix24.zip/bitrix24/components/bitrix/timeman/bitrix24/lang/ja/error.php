<?
$MESS["TM_ERROR_WRONG_DATE"] = "ローカルの日付/時刻設定でエラーが発生しました";
?>