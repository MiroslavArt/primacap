<?
$MESS["TM_STATUS_COMPLETED"] = "退勤済み";
$MESS["TM_STATUS_EXPIRED"] = "前日の退勤が未処理です";
$MESS["TM_STATUS_PAUSED"] = "休憩中";
$MESS["TM_STATUS_START"] = "出勤処理";
$MESS["TM_STATUS_WORK"] = "就業中";
?>