<?
$MESS["TM_ERROR_WRONG_DATE"] = "Klaida vietos datos/laiko nustatymuose!";
?>