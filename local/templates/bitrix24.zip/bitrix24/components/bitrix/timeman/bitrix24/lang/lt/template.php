<?
$MESS["TM_STATUS_WORK"] = "Dirbu";
$MESS["TM_STATUS_COMPLETED"] = "Uždaryta";
$MESS["TM_STATUS_START"] = "Pradėti";
$MESS["TM_STATUS_PAUSED"] = "Pertrauka";
$MESS["TM_STATUS_EXPIRED"] = "Jūs <strong>neuždarėte</strong><br/> praeitos darbo dienos.";
?>