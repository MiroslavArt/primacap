<?
$MESS["TM_ERROR_WRONG_DATE"] = "Ralat dengan tetapan tarikh/waktu tempatan!";
?>