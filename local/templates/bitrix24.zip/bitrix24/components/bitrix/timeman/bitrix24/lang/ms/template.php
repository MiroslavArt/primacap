<?
$MESS["TM_STATUS_COMPLETED"] = "Merakamkan waktu habis kerja";
$MESS["TM_STATUS_EXPIRED"] = "Anda mempunyai <strong>tidak ditutup</strong><br/>hari kerja sebelumnya.";
$MESS["TM_STATUS_PAUSED"] = "Rehat";
$MESS["TM_STATUS_START"] = "Merakamkan waktu mulai kerja";
$MESS["TM_STATUS_WORK"] = "Bekerja";
?>