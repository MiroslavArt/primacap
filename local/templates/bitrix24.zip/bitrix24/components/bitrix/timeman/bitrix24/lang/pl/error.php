<?
$MESS["TM_ERROR_WRONG_DATE"] = "Błąd ustawień lokalnej daty/czasu!";
?>