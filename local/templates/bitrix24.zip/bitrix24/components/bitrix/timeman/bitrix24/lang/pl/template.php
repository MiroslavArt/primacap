<?php
$MESS["TM_STATUS_COMPLETED"] = "Zakończenie";
$MESS["TM_STATUS_EXPIRED"] = "Masz <strong>niezakończony</strong><br/> poprzedni dzień pracy.";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "Nie <strong>wyrejestrowałeś/aś się</strong><br/>poprzedniego dnia.";
$MESS["TM_STATUS_PAUSED"] = "Na przerwie";
$MESS["TM_STATUS_START"] = "Start";
$MESS["TM_STATUS_WORK"] = "Pracuję";
