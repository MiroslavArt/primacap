<?
$MESS['TM_ERROR_WRONG_DATE'] = 'Сбой локальной даты!';
?>