<?
$MESS["TM_STATUS_WORK"] = "Работаю";
$MESS["TM_STATUS_COMPLETED"] = "Завершен";
$MESS["TM_STATUS_START"] = "Начать";
$MESS["TM_STATUS_PAUSED"] = "Перерыв";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "Вы <strong>не закрыли</strong><br/>предыдущий рабочий день.";
?>