<?
$MESS["TM_ERROR_WRONG_DATE"] = "本地时间设置错误！";
?>