<?
$MESS["TM_STATUS_COMPLETED"] = "已下班打卡";
$MESS["TM_STATUS_EXPIRED"] = "您<strong>未关闭</strong> 前一个工作日。";
$MESS["TM_STATUS_PAUSED"] = "在休息";
$MESS["TM_STATUS_START"] = "上班打卡";
$MESS["TM_STATUS_WORK"] = "正在工作";
?>