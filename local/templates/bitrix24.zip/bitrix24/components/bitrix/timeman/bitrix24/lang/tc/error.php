<?
$MESS["TM_ERROR_WRONG_DATE"] = "本機日期/時間設定錯誤！";
?>