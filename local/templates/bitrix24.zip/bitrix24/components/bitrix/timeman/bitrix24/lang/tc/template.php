<?
$MESS["TM_STATUS_COMPLETED"] = "記錄的下班時間";
$MESS["TM_STATUS_EXPIRED"] = "您前一個工作日<strong>未休息</strong>。";
$MESS["TM_STATUS_PAUSED"] = "休息時間";
$MESS["TM_STATUS_START"] = "打卡上班";
$MESS["TM_STATUS_WORK"] = "工作中";
?>