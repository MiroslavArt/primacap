<?
$MESS["TM_STATUS_COMPLETED"] = "ตอกบัตรออก";
$MESS["TM_STATUS_EXPIRED"] = "คุณยัง<strong>ไม่ได้ปิด</strong><br/>วันทำการก่อนหน้า";
$MESS["TM_STATUS_PAUSED"] = "กำลังอยู่ในช่วงพัก";
$MESS["TM_STATUS_START"] = "ตอกบัตรเข้า";
$MESS["TM_STATUS_WORK"] = "กำลังทำงาน";
?>