<?php
$MESS["TM_STATUS_COMPLETED"] = "Завершено";
$MESS["TM_STATUS_EXPIRED"] = "Ви <strong>не закрили</strong> <br/>попередній робочий день.";
$MESS["TM_STATUS_EXPIRED_MSGVER_1"] = "Ви <strong>не закрили</strong> <br/>попередній робочий день.";
$MESS["TM_STATUS_PAUSED"] = "Перерва";
$MESS["TM_STATUS_START"] = "Почати";
$MESS["TM_STATUS_WORK"] = "Працюю";
