<?
$MESS["TEMPLATE_DESCRIPTION"] = "Este modelo é projetado para acentuar os aspectos sociais da Intranet e combina ferramentas de autoria e de produtividade convencionais em um contexto que facilita a comunicação social. O layout Intranet social é um impulsionador de produtividade altamente intuitiva e requer um tempo mínimo para adoção e orientação.";
$MESS["TEMPLATE_NAME"] = "intranet social";
?>