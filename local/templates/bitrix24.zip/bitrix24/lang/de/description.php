<?
$MESS["TEMPLATE_NAME"] = "Social Intranet";
$MESS["TEMPLATE_DESCRIPTION"] = "Diese Vorlage baut auf dem Konzept eines Social Intranets auf: Hier werden übliche Arbeitstools mit den sozialen Kommunikationen vereinigt.";
?>