<?
$MESS["TEMPLATE_NAME"] = "Social Intranet";
$MESS["TEMPLATE_DESCRIPTION"] = "This template is designed for accenting the social aspects of the Intranet and combines conventional authoring and productivity tools in a context that facilitates social communication. The Social Intranet layout is a highly intuitive productivity booster and requires minimal time for adoption and orientation.";
?>