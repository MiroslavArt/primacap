<?
$MESS["TEMPLATE_DESCRIPTION"] = "L'interface est basée sur la conception de l'intranet Social qui unit les instruments classiques du travail et le format social des communications. Bitrix24 augmente l'efficacité du travail et permet à chaque employé d'avoir plus de la réussite.";
$MESS["TEMPLATE_NAME"] = "Intranet social";
?>