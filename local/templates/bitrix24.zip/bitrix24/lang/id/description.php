<?
$MESS["TEMPLATE_DESCRIPTION"] = "Template ini dirancang untuk mengaksentuasi aspek sosial Intranet dan menggabungkan alat penciptaan dan produktivitas konvensional dalam konteks yang memfasilitasi komunikasi sosial. Tata letak Intranet Sosial adalah peningkat produktivitas yang sangat intuitif dan memerlukan waktu minimal untuk adopsi dan orientasi.";
$MESS["TEMPLATE_NAME"] = "Intranet Sosial";
?>