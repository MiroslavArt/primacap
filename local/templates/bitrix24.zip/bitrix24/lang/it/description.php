<?
$MESS["TEMPLATE_DESCRIPTION"] = "Questo modello è progettato per accentuare gli aspetti social dell'Intranet e combina strumenti di authoring e produttività convenzionali in un contesto che facilita la comunicazione social. Il layout dell'Intranet social potenzia la produttività in modo altamente intuitivo e richiede un tempo minimo per l'adozione e l'orientamento.";
$MESS["TEMPLATE_NAME"] = "Intranet social";
?>