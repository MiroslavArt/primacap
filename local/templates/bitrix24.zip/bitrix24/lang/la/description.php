<?
$MESS["TEMPLATE_DESCRIPTION"] = "Esta plantilla está diseñada para acentuar los aspectos sociales de la Intranet y combinar las herramientas de autor y productividad convencional en un contexto que facilita la comunicación social. La Intranet Social es un diseño altamente intuitivo y aumenta la productividad requiriendo un mínimo tiempo para la aprobación y la orientación.";
$MESS["TEMPLATE_NAME"] = "Intranet Social";
?>