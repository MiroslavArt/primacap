<?
$MESS["TEMPLATE_NAME"] = "Socialinis Intranetas";
$MESS["TEMPLATE_DESCRIPTION"] = "Šis šablonas yra sukurtas pabrėžti socialinius aspektus intranete ir sujungia tradicinius kūrimo ir produktyvumo įrankius kontekste, kuris palengvina socialinį bendravimą. Socialinio intraneto išdėstymas yra labai intuityviai aiįkus ir reikalauja minimalaus laiko ėsisavinimui ir orientacijai.";
?>