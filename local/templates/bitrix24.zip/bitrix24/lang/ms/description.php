<?
$MESS["TEMPLATE_DESCRIPTION"] = "Templat ini direka bentuk untuk menonjolkan aspek sosial Intranet dan menggabungkan alat pengarangan dan produktiviti konvensional dalam konteks yang memudahkan komunikasi sosial. Susun atur Intranet Sosial adalah penggalak produktiviti yang sangat intuitif dan memerlukan masa yang minimum untuk penerimaan dan orientasi.";
$MESS["TEMPLATE_NAME"] = "Intranet Sosial";
?>