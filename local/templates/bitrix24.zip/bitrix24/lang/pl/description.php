<?
$MESS["TEMPLATE_DESCRIPTION"] = "Ten szablon został zaprojektowany dla zaakcentowania społecznościowych aspektów Intranetu i łączy konwencjonalne, autorskie i produktywne narzędzia w kontekście ułatwienia komunikacji społecznej. Układ Intranetu społecznościowego jest wysoce intuicyjnym, produktywnym wspomaganiem i wymaga minimum czasu do zaadaptowania go i zorientowania się.";
$MESS["TEMPLATE_NAME"] = "Intranet społecznościowy";
?>