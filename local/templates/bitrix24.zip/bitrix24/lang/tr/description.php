<?
$MESS["TEMPLATE_DESCRIPTION"] = "Bu şablon İntranetin sosyal yönünü vurgulamak ve geleneksel yaratım ve üretkenlik araçlarını sosyal iletişim bağlamında birleştirmek için tasarlanmıştır. Sosyal İntranet yerleşimi oldukça sezgisel üretkenlik arttırıcı ortamlardır ve uyum için minimum zaman gerektirir.";
$MESS["TEMPLATE_NAME"] = "Sosyal İntranet";
?>