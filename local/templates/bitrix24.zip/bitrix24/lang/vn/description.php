<?
$MESS["TEMPLATE_DESCRIPTION"] = "Mẫu này được thiết kế cho nhấn mạnh các khía cạnh xã hội của mạng nội bộ và kết hợp tác và năng suất công cụ thông thường trong một bối cảnh mà điều kiện giao tiếp xã hội. Cách bố trí mạng nội bộ xã hội là một tăng cường năng suất rất trực quan và đòi hỏi thời gian tối thiểu cho việc áp dụng và định hướng.";
$MESS["TEMPLATE_NAME"] = "Mạng nội bộ xã hội";
?>